var Mutations = {
  setInit(state,payload) {
    state.init = payload;
  }
}

export default Mutations;
