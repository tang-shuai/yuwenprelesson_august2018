var State = {
  init:false
}
export default State;
